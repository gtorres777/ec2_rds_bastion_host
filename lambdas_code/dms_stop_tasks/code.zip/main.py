import boto3

def stop_dms_tasks():
    client = boto3.client('dms')
    response = client.describe_replication_tasks()
    tasks = response['ReplicationTasks']

    for task in tasks:
        if task['Status'] == 'running':
            task_arn = task['ReplicationTaskArn']
            client.stop_replication_task(ReplicationTaskArn=task_arn)
    
    print("All DMS tasks stopped.")

def start_dms_tasks():
    client = boto3.client('dms')
    response = client.describe_replication_tasks()
    tasks = response['ReplicationTasks']

    for task in tasks:
        if task['Status'] != 'running':
            task_arn = task['ReplicationTaskArn']
            client.start_replication_task(ReplicationTaskArn=task_arn)

    print("All DMS tasks started.")

def lambda_handler(event, context):
    alarm_name = 'awsrds-premiere-prod-Low-Freeable-Memory'
    cloudwatch = boto3.client('cloudwatch')
    response = cloudwatch.describe_alarms(AlarmNames=[alarm_name])
    alarm_status = response['MetricAlarms'][0]['StateValue']
    
    if alarm_status == "ALARM":
        stop_dms_tasks()
    elif alarm_status == "OK":
        start_dms_tasks()
